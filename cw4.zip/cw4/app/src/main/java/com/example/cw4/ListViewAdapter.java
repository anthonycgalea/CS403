package com.example.cw4;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {
    ArrayList<Student> students;
    public ListViewAdapter(ArrayList<Student> students) {
        this.students=students;
    }

    @Override
    public int getCount() {
        return students.size();
    }

    @Override
    public Object getItem(int position) {
        return students.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint({"SetTextI18n", "ViewHolder"})
    public View getView(int pos, View view, ViewGroup parent) {

        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_item,parent,false);
        TextView txtName = view.findViewById(R.id.txtName);
        TextView txtAge = view.findViewById(R.id.txtAge);
        TextView txtGpa = view.findViewById(R.id.txtGpa);
        txtName.setText(((Student) getItem(pos)).name+"");
        txtAge.setText("Age: " + ((Student) getItem(pos)).age);
        txtGpa.setText("GPA: " + ((Student) getItem(pos)).gpa);
        return view;
    }


}
