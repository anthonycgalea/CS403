package com.example.cw4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<Student> students = new ArrayList<>();
        for(int i=0; i<20; i++) {
            students.add(new Student("John Doe " + i, new Random().nextInt(50), 3.5));
        }
        ListView lstView=findViewById(R.id.lstStudents);
        ListViewAdapter adapter = new ListViewAdapter(students);
        lstView.setAdapter(adapter);
    }


}